#!/bin/bash
find ../Package -name ".DS_Store" -depth -exec rm {} \;
dpkg-deb -Zgzip -b ../BK-PackageDeb daniu_1.5.3.6.deb
